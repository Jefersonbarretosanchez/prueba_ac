from django.apps import AppConfig


class ActivostiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'activosTI'
